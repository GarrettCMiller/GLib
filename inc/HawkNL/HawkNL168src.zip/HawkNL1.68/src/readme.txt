HawkNL (Hawk Network Library)

Project created and maintained by Phil Frisbie, Jr. <phil@hawksoft.com>

HawkNL has been tested on the following platforms:
Win32 (9x, ME, NT 4.0, 2000, XP, CE)
Linux (various flavors)
Solaris (2.6, 7 and 8)
AIX
MacOSX
MacOS 7+
SGI Irix

Contributors (code, ideas, comments, motivation, etc.):

Adam Driscoll <Adam.Driscoll@stanford.edu>
aj <aj@oishii.org>
Alexis <icedalex@hotmail.com>
Anthony Whitehead <anthony.whitehead@rfv.sfa.se>
cemeni <cemeni@yahoo.com>
Cristian Ferretti <cristian_ferretti@yahoo.com>
Dan Schwartz <danrsc@Stanford.edu>
Daniel Ludwig <codi@code-disaster.com>
Davide Lucchesi <davide@lucchesi.eu.org>
Derrick Schommer <derrick@kyrite.com>
Diego Losada <drodri@etsii.upm.es>
Dominique Louis <Dominique@SavageSoftware.com.au>
Elias Pschernig <elias@users.sourceforge.net>
Fabian <arakonf@yahoo.com>
Fabio Reis Cecin
Gareth Thomas <garethht@hotmail.com>
Gazin Matthieu <matthieu.gazin@wanadoo.fr>
Gillius <gillius@mail.rit.edu>
Ian Levesque <ephemeron@mac.com>
Jacob Schwartz <kevlarx@netidea.com>
Jeckle <jeckl_@club-internet.fr>
Joel Wilsson <siigron@hotmail.com>
Johnny <VILLAJ@RELIASCHEV.COM>
Kevin Jenkins <rakkar@rakkar.org>
Marco <m_f@libero.it>
Mattias Linnap <mattias.linnap@mail.ee>
maxOh <max.rheiner@hgkz.net>
Mika Kolehmainen <mimakole@cc.jyu.fi>
Mike <mike@stodge.net>
mirv <mirv_bloodangel@hotmail.com>
Pascal Lequeux <plequeux@zti.fr>
Richard Albury <ralbury@lipsinc.com>
Ryan Haksi <cryogen@infoserve.net>
Sean Middleditch
Simon Michelmore <simon-m@moving-picture.com>
Sir Morris
Stan Allan <stanallan@mailandnews.com>
Steve Williams <stevewilliams@kromestudios.com>
Tim Lyakhovetskiy <teenytim@hotmail.com>
Tomas Nilsson <d99thom@dtek.chalmers.se>
Tony Cox <directx@microsoft.com>
Wade Williams <wwilliam@cisco.com>
William DePalo [MVP] <depalow@compuserve.com>
Winston Ewert <WinstonEwert@myrealbox.com>
WingZero
Y.K. Hun <ykhun@singnet.com.sg>
