If you compile HawkNL with pthread support you will need to distibute pthreadVCE.dll along with HawkNL.dll.

If you compile with native Windows threads (the default option) then you may delete these files.